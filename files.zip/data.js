/* =========================================================
   data.js — static content, schemas and seed values.
   No fake progress history is generated here on purpose.
   ========================================================= */
window.DB = (function () {

  /* ---------------- profile baseline ---------------- */
  const PROFILE = {
    name: 'Pratham Sukhadia',
    degree: 'BCA',
    cgpa: 6.77,
    goal: "Master's in Germany",
    targetYear: 2027,
    examDate: '2026-10-17',
    startDate: '2026-08-17',
    baseline: { listening: 7.0, reading: 5.5, writing: 6.0, speaking: 6.25 },
    baselineRange: {
      listening: '6.5–7.5', reading: '5.0–5.5', writing: '5.5–6.5',
      speaking: '6.0–6.5', overall: '6.0–6.5'
    },
    targets: { listening: 7.5, reading: 7.0, writing: 7.0, speaking: 7.0, overall: 7.0, floor: 6.0 },
    germanLevel: 'A1',
    germanTarget: 'B1'
  };

  /* ---------------- weekly mandatory classes ---------------- */
  const CLASSES = {
    0: { name: 'Recovery + weekly review', tag: 'review', note: 'Light day. Review the week, plan the next one.' },
    1: { name: 'Writing Task 2', tag: 'ielts', note: 'Essay structure and argument development.' },
    2: { name: 'Speaking', tag: 'ielts', note: 'Fluency and extended answers.' },
    3: { name: 'Listening', tag: 'ielts', note: 'Prediction, spelling and distractors.' },
    4: { name: 'Reading', tag: 'ielts', note: 'Your weakest module. Bring your mistake book.' },
    5: { name: 'Writing Task 1', tag: 'ielts', note: 'Data description and overview sentences.' },
    6: { name: 'FLT / FLT review', tag: 'flt', note: 'Alternating full length test and review week.' }
  };

  /* ---------------- daily time structure ---------------- */
  const SCHEDULE = [
    { time: '07:00', label: 'Gym', kind: 'life' },
    { time: '09:30', label: 'IELTS class (until 13:00)', kind: 'ielts' },
    { time: '14:00', label: 'Main IELTS self-study (until 17:00)', kind: 'study' },
    { time: '18:00', label: 'Secondary study, work or free time (until 20:30)', kind: 'flex' },
    { time: '20:30', label: 'Dinner', kind: 'life' },
    { time: '22:00', label: 'German + vocabulary wind-down', kind: 'german' },
    { time: '00:00', label: 'Sleep target', kind: 'life' }
  ];

  /* ---------------- study modes ---------------- */
  const MODES = {
    full:   { label: 'Full day',   minutes: 165, note: '2.5–3 hours of self-study on top of class.' },
    normal: { label: 'Normal day', minutes: 105, note: '1.5–2 hours of self-study. The sustainable default.' },
    busy:   { label: 'Busy day',   minutes: 50,  note: '45–60 minutes. Protect the streak, do the highest-value work only.' }
  };

  /* ---------------- phases ---------------- */
  const PHASES = [
    { n: 1, title: 'IELTS intensive', from: '2026-08-17', to: 'exam', split: 'IELTS 80% · German 20%',
      focus: 'Reading and Writing to 7.0, hold Listening, lift Speaking.' },
    { n: 2, title: 'Germany applications + German A2', from: 'exam', to: '2026-12-31', split: 'Applications 30% · German 60% · IELTS upkeep 10%',
      focus: 'University shortlist, APS, documents, A1 → A2.' },
    { n: 3, title: 'German B1 + Germany preparation', from: '2027-01-01', to: '2027-03-31', split: 'German 70% · Applications 30%',
      focus: 'B1 exam preparation, visa file, accommodation research.' },
    { n: 4, title: 'German B2 + relocation', from: '2027-04-01', to: '2027-12-31', split: 'German 80% · Relocation 20%',
      focus: 'B2 work, blocked account, flights, arrival plan.' }
  ];

  /* ---------------- reading question types ---------------- */
  const READING_TYPES = [
    'True/False/Not Given', 'Yes/No/Not Given', 'Matching Headings', 'Matching Information',
    'Matching Features', 'Multiple Choice', 'Sentence Completion', 'Summary Completion',
    'Diagram Labels', 'Short Answer'
  ];
  const LISTENING_ERRORS = ['Spelling', 'Distractor', 'Lost concentration', 'Vocabulary',
    'Pronunciation', 'Missed information', 'Multiple choice confusion', 'Plural / singular'];
  const WRITING_ERRORS = ['Subject–verb agreement', 'Articles', 'Prepositions', 'Tense',
    'Sentence structure', 'Spelling', 'Punctuation', 'Word form', 'Weak argument',
    'Repetition', 'Cohesion', 'Vocabulary choice', 'Task response', 'Word count'];

  /* ---------------- form + table schemas ---------------- */
  const T = (name, label, extra) => Object.assign({ name, label, type: 'text' }, extra || {});
  const N = (name, label, extra) => Object.assign({ name, label, type: 'number', step: 'any' }, extra || {});
  const B = (name, label, extra) => Object.assign({ name, label, type: 'number', step: 0.5, min: 0, max: 9 }, extra || {});
  const D = (name, label, extra) => Object.assign({ name, label, type: 'date' }, extra || {});
  const S = (name, label, options, extra) => Object.assign({ name, label, type: 'select', options }, extra || {});
  const A = (name, label, extra) => Object.assign({ name, label, type: 'textarea' }, extra || {});

  const MASTERY = ['New', 'Learning', 'Familiar', 'Mastered'];

  const SCHEMAS = {
    ieltsScores: {
      title: 'IELTS score', sort: 'date',
      fields: [
        D('date', 'Date', { required: true, col: 1 }),
        T('test', 'Test name', { col: 1, placeholder: 'Cambridge 18 Test 2' }),
        T('source', 'Source', { placeholder: 'Institute / Cambridge / online' }),
        B('listening', 'Listening', { col: 1, num: 1 }),
        B('reading', 'Reading', { col: 1, num: 1 }),
        B('writing', 'Writing', { col: 1, num: 1 }),
        B('speaking', 'Speaking', { col: 1, num: 1 }),
        A('notes', 'Notes')
      ],
      derived: [{ key: 'overall', label: 'Overall', col: 1, num: 1 }]
    },
    fltTests: {
      title: 'Full length test', sort: 'date',
      fields: [
        N('number', 'FLT number', { col: 1, min: 1, step: 1 }),
        D('date', 'Date', { required: true, col: 1 }),
        T('source', 'Source', { placeholder: 'Institute FLT / Cambridge' }),
        B('listening', 'Listening', { col: 1, num: 1 }),
        B('reading', 'Reading', { col: 1, num: 1 }),
        B('writing', 'Writing', { col: 1, num: 1 }),
        B('speaking', 'Speaking', { col: 1, num: 1 }),
        N('duration', 'Duration (min)', { min: 0, step: 5 }),
        S('difficulty', 'Difficulty', ['Easy', 'Normal', 'Hard']),
        N('confidence', 'Confidence (1–5)', { min: 1, max: 5, step: 1 }),
        S('weakType', 'Question type with most errors', ['', ...READING_TYPES]),
        S('status', 'Status', ['Planned', 'Completed', 'Reviewed'], { col: 1 }),
        A('notes', 'Notes')
      ],
      derived: [{ key: 'overall', label: 'Overall', col: 1, num: 1 }]
    },
    readingSessions: {
      title: 'Reading practice', sort: 'date',
      fields: [
        D('date', 'Date', { required: true, col: 1 }),
        T('passage', 'Passage', { col: 1, placeholder: 'Cam 17 T3 P2 — Urban farming' }),
        S('questionType', 'Question type', READING_TYPES, { col: 1, required: true }),
        N('attempted', 'Questions attempted', { min: 1, step: 1, col: 1, required: true }),
        N('correct', 'Correct', { min: 0, step: 1, col: 1, required: true }),
        N('timeTaken', 'Time taken (min)', { min: 0, step: 1, col: 1 }),
        T('source', 'Source'),
        A('notes', 'Notes')
      ],
      derived: [
        { key: 'accuracy', label: 'Accuracy', col: 1 },
        { key: 'perQ', label: 'Time / question', col: 1 }
      ]
    },
    readingErrors: {
      title: 'Reading mistake', sort: 'date',
      fields: [
        D('date', 'Date', { required: true, col: 1 }),
        T('test', 'Test', { col: 1 }),
        T('passage', 'Passage'),
        T('qNumber', 'Question number', { col: 1 }),
        S('questionType', 'Question type', READING_TYPES, { col: 1, required: true }),
        T('myAnswer', 'My answer', { col: 1 }),
        T('correctAnswer', 'Correct answer', { col: 1 }),
        A('whyIChose', 'Why I chose my answer'),
        A('whyCorrect', 'Why the correct answer is correct'),
        A('evidence', 'Evidence from the passage'),
        T('vocab', 'New vocabulary'),
        A('lesson', 'Lesson learned')
      ]
    },
    writingSessions: {
      title: 'Writing entry', sort: 'date',
      fields: [
        D('date', 'Date', { required: true, col: 1 }),
        S('task', 'Task', ['Task 1', 'Task 2'], { col: 1, required: true }),
        T('essayType', 'Essay / chart type', { col: 1, placeholder: 'Opinion, Discussion, Line graph…' }),
        A('question', 'Question'),
        N('wordCount', 'Word count', { min: 0, step: 10, col: 1 }),
        N('timeTaken', 'Time (min)', { min: 0, step: 5 }),
        B('taskResponse', 'Task response', { col: 1, num: 1 }),
        B('coherence', 'Coherence & cohesion', { col: 1, num: 1 }),
        B('lexical', 'Lexical resource', { col: 1, num: 1 }),
        B('grammar', 'Grammar range & accuracy', { col: 1, num: 1 }),
        A('remarks', 'Teacher remarks'),
        A('mistakes', 'Mistakes'),
        A('rewrite', 'Rewritten version')
      ],
      derived: [{ key: 'band', label: 'Est. band', col: 1, num: 1 }]
    },
    writingErrors: {
      title: 'Writing error', sort: 'date',
      fields: [
        D('date', 'Date', { required: true, col: 1 }),
        S('category', 'Category', WRITING_ERRORS, { col: 1, required: true }),
        A('example', 'What I wrote', { col: 1 }),
        A('correction', 'Correct version', { col: 1 }),
        A('note', 'Rule to remember')
      ]
    },
    listeningSessions: {
      title: 'Listening practice', sort: 'date',
      fields: [
        D('date', 'Date', { required: true, col: 1 }),
        T('source', 'Source', { col: 1, placeholder: 'Cam 16 Test 1' }),
        S('section', 'Section', ['Section 1', 'Section 2', 'Section 3', 'Section 4', 'Full test'], { col: 1 }),
        N('total', 'Questions', { min: 1, step: 1, col: 1, required: true }),
        N('correct', 'Correct', { min: 0, step: 1, col: 1, required: true }),
        S('errorCategory', 'Main error category', ['', ...LISTENING_ERRORS], { col: 1 }),
        A('mistakes', 'Mistakes'),
        A('notes', 'Notes')
      ],
      derived: [{ key: 'band', label: 'Est. band', col: 1, num: 1 }]
    },
    speakingSessions: {
      title: 'Speaking practice', sort: 'date',
      fields: [
        D('date', 'Date', { required: true, col: 1 }),
        S('part', 'Part', ['Part 1', 'Part 2', 'Part 3'], { col: 1, required: true }),
        T('topic', 'Topic', { col: 1 }),
        N('duration', 'Duration (min)', { min: 0, step: 1, col: 1 }),
        N('confidence', 'Confidence (1–5)', { min: 1, max: 5, step: 1 }),
        B('band', 'Estimated band', { col: 1, num: 1 }),
        T('vocabulary', 'Vocabulary used'),
        A('grammarMistakes', 'Grammar mistakes'),
        A('pronunciationMistakes', 'Pronunciation mistakes'),
        T('fillers', 'Filler words', { placeholder: 'like, actually, umm' }),
        A('notes', 'Notes')
      ]
    },
    studySessions: {
      title: 'Study session', sort: 'date',
      fields: [
        D('date', 'Date', { required: true, col: 1 }),
        S('focus', 'Focus', ['Reading', 'Writing', 'Listening', 'Speaking', 'Vocabulary', 'German', 'University Research'], { col: 1, required: true }),
        N('minutes', 'Minutes', { min: 1, step: 5, col: 1, required: true }),
        T('task', 'Task', { col: 1 }),
        N('productivity', 'Productivity (1–5)', { min: 1, max: 5, step: 1, col: 1 }),
        S('completed', 'Completed', ['Yes', 'Partial', 'No']),
        A('notes', 'Notes')
      ]
    },
    ieltsVocabulary: {
      title: 'Vocabulary word', sort: 'dateAdded',
      fields: [
        T('word', 'Word', { required: true, col: 1 }),
        T('meaning', 'Meaning', { required: true, col: 1 }),
        T('synonyms', 'Synonyms', { col: 1 }),
        T('antonyms', 'Antonyms'),
        S('pos', 'Part of speech', ['noun', 'verb', 'adjective', 'adverb', 'phrase', 'other']),
        T('pronunciation', 'Pronunciation'),
        A('example', 'Example sentence', { col: 1 }),
        T('topic', 'Topic', { col: 1, placeholder: 'Environment, Education…' }),
        S('mastery', 'Mastery', MASTERY, { col: 1 }),
        D('dateAdded', 'Date added')
      ]
    },
    germanVocabulary: {
      title: 'German word', sort: 'dateAdded',
      fields: [
        T('word', 'German word', { required: true, col: 1 }),
        S('article', 'Article', ['', 'der', 'die', 'das'], { col: 1 }),
        T('meaning', 'English meaning', { required: true, col: 1 }),
        T('localMeaning', 'Hindi / Gujarati meaning'),
        T('plural', 'Plural', { col: 1 }),
        T('pronunciation', 'Pronunciation'),
        T('ipa', 'IPA', { col: 1 }),
        A('example', 'Example sentence'),
        T('topic', 'Topic', { col: 1 }),
        S('level', 'CEFR level', ['A1', 'A2', 'B1', 'B2'], { col: 1 }),
        S('mastery', 'Mastery', MASTERY, { col: 1 }),
        D('dateAdded', 'Date learned')
      ]
    },
    pronunciation: {
      title: 'Pronunciation entry', sort: 'dateAdded',
      fields: [
        T('word', 'German word or phrase', { required: true, col: 1 }),
        T('pronunciation', 'Pronunciation', { col: 1 }),
        T('ipa', 'IPA', { col: 1 }),
        T('english', 'English approximation', { col: 1 }),
        T('meaning', 'Meaning', { col: 1 }),
        A('example', 'Example'),
        A('notes', 'Notes'),
        D('dateAdded', 'Date added')
      ]
    },
    resources: {
      title: 'Resource', sort: 'title',
      fields: [
        T('title', 'Title', { required: true, col: 1 }),
        S('group', 'Group', ['IELTS', 'German'], { col: 1, required: true }),
        T('category', 'Category', { col: 1, placeholder: 'Reading, Grammar, Conversation…' }),
        T('level', 'Level', { col: 1, placeholder: 'A1, Band 7, Any' }),
        T('source', 'Source', { col: 1 }),
        T('url', 'URL', { type: 'url', required: true }),
        S('status', 'Status', ['Not started', 'In progress', 'Completed'], { col: 1 }),
        N('rating', 'Rating (1–5)', { min: 1, max: 5, step: 1 }),
        A('notes', 'Notes')
      ]
    },
    notes: {
      title: 'Note', sort: 'updated',
      fields: [
        T('title', 'Title', { required: true, col: 1 }),
        S('category', 'Category', ['IELTS', 'Reading', 'Writing', 'Listening', 'Speaking', 'Grammar',
          'Vocabulary', 'German', 'Germany', 'University', 'Application', 'Visa', 'General'], { col: 1 }),
        T('tags', 'Tags', { col: 1, placeholder: 'comma, separated' }),
        A('body', 'Note', { rows: 10, help: 'Markdown-lite: # heading, - bullet, **bold**, [text](url)' })
      ]
    },
    universities: {
      title: 'University', sort: 'deadline',
      fields: [
        T('name', 'University', { required: true, col: 1 }),
        T('program', 'Program', { col: 1 }),
        T('city', 'City', { col: 1 }),
        S('degree', 'Degree', ['M.Sc.', 'M.A.', 'M.Eng.', 'MBA', 'Other']),
        S('language', 'Language of instruction', ['English', 'German', 'Mixed'], { col: 1 }),
        B('ieltsReq', 'IELTS requirement', { col: 1, num: 1 }),
        T('germanReq', 'German requirement', { placeholder: 'None / A2 / B1' }),
        N('cgpaReq', 'CGPA requirement', { step: 0.01 }),
        T('ects', 'ECTS / credit requirement'),
        D('deadline', 'Application deadline', { col: 1 }),
        T('portal', 'Application portal', { type: 'url' }),
        S('status', 'Status', ['Researching', 'Eligible', 'Shortlisted', 'Documents preparing',
          'Applied', 'Interview', 'Accepted', 'Rejected', 'Waitlisted'], { col: 1 }),
        A('notes', 'Notes')
      ]
    },
    documents: {
      title: 'Document', sort: 'name',
      fields: [
        T('name', 'Document', { required: true, col: 1 }),
        S('category', 'Category', ['Identity', 'Academic', 'Language', 'Application', 'APS', 'Financial', 'Visa'], { col: 1 }),
        S('status', 'Status', ['Not started', 'In progress', 'Completed'], { col: 1 }),
        D('dueDate', 'Needed by'),
        A('notes', 'Notes')
      ]
    }
  };

  /* ---------------- document checklist seed ---------------- */
  const DOCS_SEED = [
    ['Passport', 'Identity'], ['BCA degree certificate', 'Academic'],
    ['Provisional certificate', 'Academic'], ['Semester transcripts (all 6)', 'Academic'],
    ['10th standard certificate', 'Academic'], ['12th standard certificate', 'Academic'],
    ['IELTS score report', 'Language'], ['German language certificate (A1/A2)', 'Language'],
    ['CV / résumé', 'Application'], ['Statement of purpose', 'Application'],
    ['Letter of recommendation 1', 'Application'], ['Letter of recommendation 2', 'Application'],
    ['APS certificate', 'APS'], ['APS application documents', 'APS'],
    ['University-specific forms', 'Application'], ['Blocked account proof', 'Financial'],
    ['Health insurance', 'Financial'], ['Visa application form', 'Visa'],
    ['Visa appointment confirmation', 'Visa'], ['Motivation letter (visa)', 'Visa']
  ].map(([name, category]) => ({ name, category, status: 'Not started', notes: '' }));

  /* ---------------- resources seed ---------------- */
  const RES_SEED = [
    { title: 'Nicos Weg — A1 full course', group: 'German', category: 'Conversation', level: 'A1', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/nicos-weg/c-36519789', status: 'Not started' },
    { title: 'Nicos Weg — A2 full course', group: 'German', category: 'Conversation', level: 'A2', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/nicos-weg-a2/c-40760437', status: 'Not started' },
    { title: 'Nicos Weg — B1 full course', group: 'German', category: 'Conversation', level: 'B1', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/nicos-weg-b1/c-41652114', status: 'Not started' },
    { title: 'DW German placement test', group: 'German', category: 'Assessment', level: 'Any', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/placement-test/c-56553517', status: 'Not started' },
    { title: 'Easy German — Super Easy German playlist', group: 'German', category: 'Listening', level: 'A1', source: 'Easy German', url: 'https://www.youtube.com/@EasyGerman/playlists', status: 'Not started' },
    { title: 'Learn German with Anja', group: 'German', category: 'Pronunciation', level: 'A1', source: 'YouTube', url: 'https://www.youtube.com/@LearnGermanwithAnja', status: 'Not started' },
    { title: 'Goethe-Institut A1 practice materials', group: 'German', category: 'Grammar', level: 'A1', source: 'Goethe-Institut', url: 'https://www.goethe.de/en/spr/kup/prf/prf/gzsd1.html', status: 'Not started' },
    { title: 'Goethe-Institut B1 practice materials', group: 'German', category: 'Grammar', level: 'B1', source: 'Goethe-Institut', url: 'https://www.goethe.de/en/spr/kup/prf/prf/gzb1.html', status: 'Not started' },
    { title: 'DW Deutschtrainer A1', group: 'German', category: 'Vocabulary', level: 'A1', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/deutschtrainer/c-33269758', status: 'Not started' },
    { title: 'Deutschlandlabor — culture videos', group: 'German', category: 'German Culture', level: 'A2', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/deutschlandlabor/c-38446272', status: 'Not started' },
    { title: 'IELTS Academic Reading practice tests', group: 'IELTS', category: 'Reading', level: 'Band 6–8', source: 'IELTS.org', url: 'https://ielts.org/take-a-test/preparation-resources/sample-test-questions', status: 'Not started' },
    { title: 'British Council — Road to IELTS free', group: 'IELTS', category: 'Mock Tests', level: 'Any', source: 'British Council', url: 'https://takeielts.britishcouncil.org/take-ielts/prepare/free-ielts-practice-tests', status: 'Not started' },
    { title: 'IELTS Liz — Writing Task 2 lessons', group: 'IELTS', category: 'Writing', level: 'Band 7', source: 'IELTS Liz', url: 'https://ieltsliz.com/ielts-writing-task-2/', status: 'Not started' },
    { title: 'IELTS Speaking part 2 topic bank', group: 'IELTS', category: 'Speaking', level: 'Any', source: 'IELTS Liz', url: 'https://ieltsliz.com/ielts-speaking-part-2-topics/', status: 'Not started' },
    { title: 'Cambridge IELTS listening tests (official samples)', group: 'IELTS', category: 'Listening', level: 'Any', source: 'IELTS.org', url: 'https://ielts.org/take-a-test/preparation-resources/sample-test-questions', status: 'Not started' },
    { title: 'Academic Word List (Coxhead)', group: 'IELTS', category: 'Vocabulary', level: 'Band 7', source: 'Victoria University', url: 'https://www.wgtn.ac.nz/lals/resources/academicwordlist', status: 'Not started' },
    { title: 'Grammar for IELTS — perfect tenses refresher', group: 'IELTS', category: 'Grammar', level: 'Band 6–7', source: 'British Council LearnEnglish', url: 'https://learnenglish.britishcouncil.org/grammar', status: 'Not started' },
    { title: 'DAAD — study in Germany programme search', group: 'IELTS', category: 'Academic English', level: 'Any', source: 'DAAD', url: 'https://www2.daad.de/deutschland/studienangebote/international-programmes/en/', status: 'Not started' }
  ];

  /* ---------------- CEFR roadmap ---------------- */
  const CEFR = {
    A1: { vocabulary: '600 words', grammar: 'sein, haben, present tense, W-questions', listening: 'slow classroom speech',
      speaking: 'introduce yourself, order food', reading: 'signs, short messages', writing: 'a short personal email' },
    A2: { vocabulary: '1,300 words', grammar: 'Perfekt, modal verbs, dative, separable verbs', listening: 'everyday dialogues',
      speaking: 'describe routine, past events', reading: 'ads, simple articles', writing: 'letters, forms' },
    B1: { vocabulary: '2,400 words', grammar: 'Konjunktiv II, passive, relative clauses, Genitiv', listening: 'radio, university announcements',
      speaking: 'give opinions, handle problems', reading: 'newspaper articles', writing: 'complaint, opinion text' },
    B2: { vocabulary: '4,000 words', grammar: 'Nominalisierung, complex connectors, Konjunktiv I', listening: 'lectures, fast native speech',
      speaking: 'argue a position fluently', reading: 'academic texts', writing: 'structured essay' },
    C1: { vocabulary: '8,000 words', grammar: 'full range, idiomatic control', listening: 'anything, including dialect-tinged speech',
      speaking: 'near-native flexibility', reading: 'literature, technical papers', writing: 'academic register' }
  };

  /* ---------------- tips database ---------------- */
  const TIPS = {
    Reading: [
      'True/False/Not Given: "Not Given" means the passage is silent, not that the statement feels wrong. Prove it or leave it.',
      'Matching Headings: never match on one keyword. Read the paragraph, close your eyes, say its central idea in five words, then pick.',
      'Matching Information: scan for the specific detail, not the topic. Detail questions live in one sentence.',
      'Multiple choice: eliminate two options first. Wrong options usually overstate ("all", "never") or swap a detail.',
      'Sentence completion: check grammar before you write. If a noun is needed, an adjective is wrong even if the meaning fits.',
      'Summary completion: read the whole summary once first. It is a compressed paraphrase, so predict word types before scanning.',
      'Keyword scanning: scan for names, numbers, dates and capitals first. They are the only words the passage cannot paraphrase.',
      'Paraphrasing: the answer is almost never the question word. Train yourself to expect a synonym.',
      'Time management: 20 minutes per passage. If a question costs more than 90 seconds, mark it and move on.',
      'Never leave blanks. An unanswered question is a guaranteed zero, a guess is not.',
      'Read the question stem twice, the passage once. Most errors are misread questions, not unknown words.',
      'If you finish a passage with 6 wrong answers, do not do another passage. Analyse those six first.'
    ],
    Writing: [
      'Task response: answer every part of the prompt. A brilliant essay that ignores half the question caps at 6.',
      'Coherence: one idea per paragraph, and say that idea in the first sentence. Examiners look for topic sentences.',
      'Cohesion: vary your linkers. "Moreover" three times is worse than a well-placed "This in turn means".',
      'Lexical resource: precision beats decoration. "Significant" used correctly outranks "plethora" used oddly.',
      'Grammar: aim for accurate complexity, not maximum complexity. Two clean complex sentences per paragraph is enough.',
      'Introduction: paraphrase the question, then state your position in one sentence. No background waffle.',
      'Conclusion: restate the position and add nothing new. Two sentences, always written.',
      'Examples: specific and plausible beats real. "In India, urban commuters spend around two hours a day travelling" works.',
      'Task 1: the overview sentence is compulsory. Without it, Task Achievement stays at 5.',
      'Task 1: report trends and comparisons, not every number. Pick the extremes and the turning points.',
      'Word count: 260–280 for Task 2 is the sweet spot. Longer means more grammar mistakes, not more marks.',
      'Rewrite your corrected essay by hand once. Corrections you only read do not transfer.'
    ],
    Listening: [
      'Prediction: use the pause to read ahead and predict the word type. Knowing "a number is coming" halves the difficulty.',
      'Spelling: names and places are spelled out for a reason. Write letters as you hear them, tidy up later.',
      'Distractors: speakers correct themselves. The answer is usually the second number or the word after "actually".',
      'Signposting: "however", "but", "although" mean the answer is about to change. Mark them in the question paper.',
      'Concentration: if you lose one answer, let it go immediately. Chasing it costs the next three.',
      'Multiple choice in Section 3: read all options before the audio. Options are paraphrased, not quoted.',
      'Plural and singular cost real marks. If you hear "s", write it.',
      'Section 4 has no break. Read all ten questions during the introduction.'
    ],
    Speaking: [
      'Fluency: hesitation hurts more than a small grammar error. Keep talking, self-correct as you go.',
      'Pronunciation: slow down. Clarity scores higher than speed, and speed hides your good vocabulary.',
      'Part 1: two to three sentences per answer. One-word answers waste the easiest marks in the test.',
      'Part 2: use the one minute to write four bullet points, not sentences. Cover all prompts on the card.',
      'Part 3: give an opinion, a reason and an example. Then stop. Rambling invites errors.',
      'Extending answers: add a reason ("because"), a contrast ("although") or an example ("for instance") to every answer.',
      'Reduce fillers: replace "umm" with a full phrase like "That is an interesting question, I would say…".',
      'Record yourself once a week and listen. You will hear the repeated words you cannot notice while speaking.'
    ],
    German: [
      'Pronunciation: German "w" is English "v", and "v" is often "f". Wasser sounds like "vasser".',
      'Learn every noun with its article. "Haus" is half-learned, "das Haus" is learned.',
      'Umlauts change meaning, not decoration: schon (already) versus schön (beautiful).',
      'The verb goes second in a main clause, and last in a subordinate clause. Build the habit now, before B1.',
      'Nominative, accusative, dative: learn cases through verbs, not tables. "Ich helfe dir" teaches dative better than a chart.',
      'Separable verbs split: "Ich stehe um sieben Uhr auf". The prefix waits at the end of the sentence.',
      'Plurals are irregular. Learn the plural at the same time as the singular or you will learn each word twice.',
      'The "ch" sound has two versions: soft after e/i (ich), hard after a/o/u (Buch).',
      'Numbers are said backwards: 21 is einundzwanzig, "one and twenty". Practise until it stops surprising you.',
      'Listen for twenty minutes daily even when you understand nothing. Ear training precedes comprehension.',
      'Speak from day one, in full sentences, out loud. Silent learning produces silent students.'
    ]
  };

  /* ---------------- German A1/A2 lesson bank ---------------- */
  const w = (de, en, ipa, article) => ({ de, en, ipa, article: article || '' });
  const LESSONS = [
    {
      level: 'A1', topic: 'Introducing yourself',
      words: [w('ich', 'I', 'ɪç'), w('du', 'you (informal)', 'duː'), w('heißen', 'to be called', 'ˈhaɪsn̩'),
        w('kommen', 'to come', 'ˈkɔmən'), w('wohnen', 'to live', 'ˈvoːnən'), w('studieren', 'to study', 'ʃtuˈdiːʁən'),
        w('lernen', 'to learn', 'ˈlɛʁnən'), w('sprechen', 'to speak', 'ˈʃpʁɛçn̩'),
        w('Student', 'student (m)', 'ʃtuˈdɛnt', 'der'), w('Deutschland', 'Germany', 'ˈdɔɪtʃlant', 'das')],
      grammar: { title: 'sein — to be', body: 'The most used verb in German. Memorise it as a rhythm, not a table.',
        examples: ['ich bin — I am', 'du bist — you are', 'er/sie/es ist — he/she/it is', 'wir sind — we are', 'ihr seid — you all are', 'sie/Sie sind — they/you (formal) are'] },
      pronunciation: { focus: 'ei and ie', tip: 'Read the second letter: "ei" sounds like "eye", "ie" sounds like "ee".', words: ['heißen /ˈhaɪsn̩/', 'sie /ziː/', 'mein /maɪn/', 'wie /viː/'] },
      listening: { title: 'Nicos Weg A1 — Hallo!', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/nicos-weg/c-36519789' },
      speaking: ['Ich heiße Pratham.', 'Ich komme aus Indien.', 'Ich wohne in Gujarat.', 'Ich lerne Deutsch.', 'Ich möchte in Deutschland studieren.'],
      quiz: { q: 'Complete: Ich ___ Pratham.', options: ['bin', 'bist', 'sind'], answer: 0 },
      culture: 'Germans shake hands and use "Sie" with strangers. Switching to "du" is usually offered by the older or senior person.'
    },
    {
      level: 'A1', topic: 'Numbers and age',
      words: [w('eins', 'one', 'aɪns'), w('zwei', 'two', 'tsvaɪ'), w('drei', 'three', 'dʁaɪ'), w('zehn', 'ten', 'tseːn'),
        w('zwanzig', 'twenty', 'ˈtsvantsɪç'), w('hundert', 'hundred', 'ˈhʊndɐt'), w('Jahr', 'year', 'jaːɐ̯', 'das'),
        w('alt', 'old', 'alt'), w('Nummer', 'number', 'ˈnʊmɐ', 'die'), w('Telefonnummer', 'phone number', 'teleˈfoːnnʊmɐ', 'die')],
      grammar: { title: 'Reversed numbers', body: 'Two-digit numbers are spoken units-first, joined by "und".',
        examples: ['21 = einundzwanzig', '34 = vierunddreißig', '99 = neunundneunzig', 'Ich bin zwanzig Jahre alt.'] },
      pronunciation: { focus: 'z and s', tip: '"z" is "ts", "s" before a vowel is "z". Zwanzig starts "tsv".', words: ['zwei /tsvaɪ/', 'sechs /zɛks/', 'sieben /ˈziːbn̩/'] },
      listening: { title: 'Deutschtrainer — Zahlen', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/deutschtrainer/c-33269758' },
      speaking: ['Ich bin einundzwanzig Jahre alt.', 'Meine Nummer ist null neun fünf.', 'Wie alt bist du?', 'Das kostet zehn Euro.', 'Ich habe zwei Schwestern.'],
      quiz: { q: 'How do you say 42?', options: ['vierzigzwei', 'zweiundvierzig', 'vierundzwanzig'], answer: 1 },
      culture: 'Germans count on their fingers starting with the thumb. Holding up an index finger often gets you two beers.'
    },
    {
      level: 'A1', topic: 'Articles and nouns',
      words: [w('Haus', 'house', 'haʊs', 'das'), w('Buch', 'book', 'buːx', 'das'), w('Tisch', 'table', 'tɪʃ', 'der'),
        w('Stuhl', 'chair', 'ʃtuːl', 'der'), w('Tür', 'door', 'tyːɐ̯', 'die'), w('Fenster', 'window', 'ˈfɛnstɐ', 'das'),
        w('Zimmer', 'room', 'ˈtsɪmɐ', 'das'), w('Wohnung', 'flat', 'ˈvoːnʊŋ', 'die'),
        w('Universität', 'university', 'univɛʁziˈtɛːt', 'die'), w('Bibliothek', 'library', 'biblioˈteːk', 'die')],
      grammar: { title: 'der, die, das', body: 'Every noun has a gender and it is not negotiable. Two reliable patterns: nouns ending -ung, -heit, -keit, -schaft, -tät are die; nouns ending -chen and -ment are das.',
        examples: ['der Tisch → die Tische', 'die Wohnung → die Wohnungen', 'das Haus → die Häuser', 'All plurals take "die".'] },
      pronunciation: { focus: 'ü', tip: 'Say "ee" then round your lips without moving your tongue. That is ü.', words: ['Tür /tyːɐ̯/', 'für /fyːɐ̯/', 'müde /ˈmyːdə/'] },
      listening: { title: 'Nicos Weg A1 — Meine Wohnung', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/nicos-weg/c-36519789' },
      speaking: ['Das ist mein Zimmer.', 'Die Wohnung ist klein.', 'Der Tisch ist neu.', 'Ich lerne in der Bibliothek.', 'Die Universität ist groß.'],
      quiz: { q: 'Which article goes with "Wohnung"?', options: ['der', 'die', 'das'], answer: 1 },
      culture: 'German flats are advertised by room count excluding kitchen and bath. A "2-Zimmer-Wohnung" has two rooms in total.'
    },
    {
      level: 'A1', topic: 'Present tense verbs',
      words: [w('machen', 'to do', 'ˈmaxn̩'), w('arbeiten', 'to work', 'ˈaʁbaɪtn̩'), w('essen', 'to eat', 'ˈɛsn̩'),
        w('trinken', 'to drink', 'ˈtʁɪŋkn̩'), w('gehen', 'to go', 'ˈɡeːən'), w('fahren', 'to travel', 'ˈfaːʁən'),
        w('lesen', 'to read', 'ˈleːzn̩'), w('schreiben', 'to write', 'ˈʃʁaɪbn̩'),
        w('Arbeit', 'work', 'ˈaʁbaɪt', 'die'), w('Tag', 'day', 'taːk', 'der')],
      grammar: { title: 'Regular present tense endings', body: 'Take the stem and add the ending. This covers most verbs.',
        examples: ['ich mach-e', 'du mach-st', 'er mach-t', 'wir mach-en', 'ihr mach-t', 'sie mach-en'] },
      pronunciation: { focus: 'final -en', tip: 'Unstressed -en collapses to a soft "n". "machen" sounds like "MAKH-n".', words: ['machen /ˈmaxn̩/', 'gehen /ˈɡeːən/', 'lesen /ˈleːzn̩/'] },
      listening: { title: 'Easy German — Super Easy German', source: 'Easy German', url: 'https://www.youtube.com/@EasyGerman/playlists' },
      speaking: ['Ich arbeite am Computer.', 'Was machst du heute?', 'Ich lese ein Buch.', 'Wir gehen ins Kino.', 'Er trinkt Kaffee.'],
      quiz: { q: 'Complete: Du ___ Deutsch.', options: ['lerne', 'lernst', 'lernt'], answer: 1 },
      culture: 'Punctuality is a form of respect in Germany. Arriving five minutes early is arriving on time.'
    },
    {
      level: 'A1', topic: 'Food and shopping',
      words: [w('Brot', 'bread', 'bʁoːt', 'das'), w('Wasser', 'water', 'ˈvasɐ', 'das'), w('Milch', 'milk', 'mɪlç', 'die'),
        w('Apfel', 'apple', 'ˈapfl̩', 'der'), w('Käse', 'cheese', 'ˈkɛːzə', 'der'), w('kaufen', 'to buy', 'ˈkaʊfn̩'),
        w('kosten', 'to cost', 'ˈkɔstn̩'), w('billig', 'cheap', 'ˈbɪlɪç'), w('teuer', 'expensive', 'ˈtɔɪɐ'),
        w('Supermarkt', 'supermarket', 'ˈzuːpɐmaʁkt', 'der')],
      grammar: { title: 'Accusative case', body: 'The direct object changes only in masculine: der → den. Feminine, neuter and plural stay the same.',
        examples: ['Ich kaufe den Apfel.', 'Ich kaufe die Milch.', 'Ich kaufe das Brot.', 'Ich möchte einen Kaffee.'] },
      pronunciation: { focus: 'w and v', tip: '"w" = English v. "v" is usually "f".', words: ['Wasser /ˈvasɐ/', 'Wein /vaɪn/', 'viel /fiːl/'] },
      listening: { title: 'Nicos Weg A1 — Einkaufen', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/nicos-weg/c-36519789' },
      speaking: ['Ich möchte einen Kaffee, bitte.', 'Was kostet das Brot?', 'Das ist zu teuer.', 'Ich kaufe Milch und Käse.', 'Zahlen, bitte.'],
      quiz: { q: 'Complete: Ich kaufe ___ Apfel.', options: ['der', 'den', 'dem'], answer: 1 },
      culture: 'Bring your own bag and expect to bag groceries yourself, fast. German checkout speed is a sport.'
    },
    {
      level: 'A1', topic: 'Time and daily routine',
      words: [w('Uhr', "o'clock", 'uːɐ̯', 'die'), w('Morgen', 'morning', 'ˈmɔʁɡn̩', 'der'), w('Abend', 'evening', 'ˈaːbn̩t', 'der'),
        w('früh', 'early', 'fʁyː'), w('spät', 'late', 'ʃpɛːt'), w('aufstehen', 'to get up', 'ˈaʊfʃteːən'),
        w('schlafen', 'to sleep', 'ˈʃlaːfn̩'), w('anfangen', 'to begin', 'ˈanfaŋən'),
        w('Woche', 'week', 'ˈvɔxə', 'die'), w('Montag', 'Monday', 'ˈmoːntaːk', 'der')],
      grammar: { title: 'Separable verbs', body: 'The prefix detaches and moves to the end of the clause.',
        examples: ['aufstehen → Ich stehe um sieben Uhr auf.', 'anfangen → Der Kurs fängt um neun an.', 'einkaufen → Wir kaufen am Samstag ein.'] },
      pronunciation: { focus: 'sp and st', tip: 'At the start of a word or syllable, "sp" = "shp" and "st" = "sht".', words: ['spät /ʃpɛːt/', 'Student /ʃtuˈdɛnt/', 'aufstehen /ˈaʊfʃteːən/'] },
      listening: { title: 'Deutschtrainer — Tagesablauf', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/deutschtrainer/c-33269758' },
      speaking: ['Ich stehe um sieben Uhr auf.', 'Der Unterricht fängt um halb zehn an.', 'Am Abend lerne ich Deutsch.', 'Ich gehe um zwölf Uhr schlafen.', 'Wie spät ist es?'],
      quiz: { q: 'Correct sentence?', options: ['Ich aufstehe um sieben.', 'Ich stehe um sieben auf.', 'Ich stehe auf um sieben.'], answer: 1 },
      culture: '"Halb zehn" means 9:30, not 10:30. German half-hours look forward to the coming hour.'
    },
    {
      level: 'A1', topic: 'Family and people',
      words: [w('Familie', 'family', 'faˈmiːliə', 'die'), w('Mutter', 'mother', 'ˈmʊtɐ', 'die'), w('Vater', 'father', 'ˈfaːtɐ', 'der'),
        w('Schwester', 'sister', 'ˈʃvɛstɐ', 'die'), w('Bruder', 'brother', 'ˈbʁuːdɐ', 'der'), w('Freund', 'friend (m)', 'fʁɔɪnt', 'der'),
        w('verheiratet', 'married', 'fɛɐ̯ˈhaɪʁaːtət'), w('Kind', 'child', 'kɪnt', 'das'),
        w('Beruf', 'profession', 'bəˈʁuːf', 'der'), w('Name', 'name', 'ˈnaːmə', 'der')],
      grammar: { title: 'Possessive articles', body: 'mein, dein, sein, ihr take the gender of the thing owned, not the owner.',
        examples: ['mein Vater (der)', 'meine Mutter (die)', 'mein Kind (das)', 'meine Eltern (plural)'] },
      pronunciation: { focus: 'r at the end', tip: 'Final -er sounds like a soft "ah". Mutter is "MOO-tah".', words: ['Mutter /ˈmʊtɐ/', 'Vater /ˈfaːtɐ/', 'Bruder /ˈbʁuːdɐ/'] },
      listening: { title: 'Nicos Weg A1 — Familie', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/nicos-weg/c-36519789' },
      speaking: ['Das ist meine Familie.', 'Mein Vater arbeitet in Vadodara.', 'Ich habe eine Schwester.', 'Meine Mutter heißt …', 'Ich bin nicht verheiratet.'],
      quiz: { q: 'Complete: ___ Mutter ist Lehrerin.', options: ['Mein', 'Meine', 'Meinen'], answer: 1 },
      culture: 'Germans separate work and private life sharply. Colleagues may never learn your family details, and that is normal.'
    },
    {
      level: 'A1', topic: 'Modal verbs',
      words: [w('können', 'can', 'ˈkœnən'), w('müssen', 'must', 'ˈmʏsn̩'), w('wollen', 'to want', 'ˈvɔlən'),
        w('möchten', 'would like', 'ˈmœçtn̩'), w('dürfen', 'may', 'ˈdʏʁfn̩'), w('sollen', 'should', 'ˈzɔlən'),
        w('helfen', 'to help', 'ˈhɛlfn̩'), w('brauchen', 'to need', 'ˈbʁaʊxn̩'),
        w('Hilfe', 'help', 'ˈhɪlfə', 'die'), w('Problem', 'problem', 'pʁoˈbleːm', 'das')],
      grammar: { title: 'Modal verb + infinitive at the end', body: 'The modal is conjugated in position two, the main verb goes to the end unchanged.',
        examples: ['Ich kann Deutsch sprechen.', 'Ich muss heute lernen.', 'Ich möchte in Deutschland studieren.', 'Kannst du mir helfen?'] },
      pronunciation: { focus: 'ö', tip: 'Say "eh" and round your lips. That is ö in können.', words: ['können /ˈkœnən/', 'möchten /ˈmœçtn̩/', 'schön /ʃøːn/'] },
      listening: { title: 'Learn German with Anja — modal verbs', source: 'YouTube', url: 'https://www.youtube.com/@LearnGermanwithAnja' },
      speaking: ['Ich kann ein bisschen Deutsch sprechen.', 'Ich muss für IELTS lernen.', 'Ich möchte einen Master machen.', 'Kannst du langsamer sprechen?', 'Ich brauche Hilfe.'],
      quiz: { q: 'Correct word order?', options: ['Ich kann sprechen Deutsch.', 'Ich kann Deutsch sprechen.', 'Ich Deutsch kann sprechen.'], answer: 1 },
      culture: '"Ich möchte" is the polite default in shops and offices. "Ich will" sounds blunt to German ears.'
    },
    {
      level: 'A1', topic: 'City and directions',
      words: [w('Stadt', 'city', 'ʃtat', 'die'), w('Bahnhof', 'station', 'ˈbaːnhoːf', 'der'), w('Straße', 'street', 'ˈʃtʁaːsə', 'die'),
        w('links', 'left', 'lɪŋks'), w('rechts', 'right', 'ʁɛçts'), w('geradeaus', 'straight ahead', 'ɡəʁaːdəˈʔaʊs'),
        w('nah', 'near', 'naː'), w('weit', 'far', 'vaɪt'),
        w('Bus', 'bus', 'bʊs', 'der'), w('Zug', 'train', 'tsuːk', 'der')],
      grammar: { title: 'Dative after location prepositions', body: 'in, an, auf, bei, zu, mit take the dative when describing location.',
        examples: ['Ich bin in der Stadt.', 'Ich fahre mit dem Bus.', 'Ich gehe zum Bahnhof.', 'Die Bibliothek ist bei der Universität.'] },
      pronunciation: { focus: 'ß and s', tip: 'ß is always a sharp "s" and never doubles as "z".', words: ['Straße /ˈʃtʁaːsə/', 'groß /ɡʁoːs/', 'heißen /ˈhaɪsn̩/'] },
      listening: { title: 'Nicos Weg A1 — Orientierung', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/nicos-weg/c-36519789' },
      speaking: ['Wo ist der Bahnhof?', 'Gehen Sie geradeaus.', 'Ist es weit von hier?', 'Ich fahre mit dem Zug.', 'Die Straße heißt Hauptstraße.'],
      quiz: { q: 'Complete: Ich fahre mit ___ Bus.', options: ['der', 'den', 'dem'], answer: 2 },
      culture: 'Public transport works on trust and inspectors. A ticket you forgot to validate is treated exactly like no ticket.'
    },
    {
      level: 'A1', topic: 'University and study language',
      words: [w('Studium', 'studies', 'ˈʃtuːdiʊm', 'das'), w('Vorlesung', 'lecture', 'ˈfoːɐ̯leːzʊŋ', 'die'),
        w('Prüfung', 'exam', 'ˈpʁyːfʊŋ', 'die'), w('Note', 'grade', 'ˈnoːtə', 'die'), w('Semester', 'semester', 'zeˈmɛstɐ', 'das'),
        w('Bewerbung', 'application', 'bəˈvɛʁbʊŋ', 'die'), w('Zeugnis', 'certificate', 'ˈtsɔɪknɪs', 'das'),
        w('Frist', 'deadline', 'fʁɪst', 'die'), w('Antrag', 'formal application', 'ˈantʁaːk', 'der'),
        w('Unterlagen', 'documents', 'ˈʊntɐlaːɡn̩', 'die')],
      grammar: { title: 'Question words', body: 'W-questions put the question word first and the verb second.',
        examples: ['Wann ist die Frist?', 'Wo studierst du?', 'Was brauchen Sie?', 'Warum Deutschland?', 'Wie lange dauert das Studium?'] },
      pronunciation: { focus: 'ung ending', tip: '-ung is "oong" with a nasal ending, always stressed on the syllable before it.', words: ['Vorlesung /ˈfoːɐ̯leːzʊŋ/', 'Prüfung /ˈpʁyːfʊŋ/', 'Bewerbung /bəˈvɛʁbʊŋ/'] },
      listening: { title: 'Deutschlandlabor — Studieren', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/deutschlandlabor/c-38446272' },
      speaking: ['Ich möchte einen Master in Deutschland machen.', 'Meine Unterlagen sind fertig.', 'Wann ist die Bewerbungsfrist?', 'Ich habe einen Bachelor in Informatik.', 'Ich lerne Deutsch für mein Studium.'],
      quiz: { q: 'What does "Frist" mean?', options: ['grade', 'deadline', 'lecture'], answer: 1 },
      culture: 'German universities run on formal deadlines and complete document sets. An incomplete application is simply not reviewed.'
    },
    {
      level: 'A1', topic: 'Weather and small talk',
      words: [w('Wetter', 'weather', 'ˈvɛtɐ', 'das'), w('Regen', 'rain', 'ˈʁeːɡn̩', 'der'), w('Schnee', 'snow', 'ʃneː', 'der'),
        w('warm', 'warm', 'vaʁm'), w('kalt', 'cold', 'kalt'), w('Sonne', 'sun', 'ˈzɔnə', 'die'),
        w('Wind', 'wind', 'vɪnt', 'der'), w('scheinen', 'to shine', 'ˈʃaɪnən'),
        w('Winter', 'winter', 'ˈvɪntɐ', 'der'), w('Sommer', 'summer', 'ˈzɔmɐ', 'der')],
      grammar: { title: 'Impersonal "es"', body: 'Weather sentences use "es" as an empty subject.',
        examples: ['Es regnet.', 'Es ist kalt.', 'Es schneit im Winter.', 'Es gibt viel Wind heute.'] },
      pronunciation: { focus: 'ch after a/o/u', tip: 'Hard "ch" from the throat, like clearing it gently: Buch, machen, Nacht.', words: ['machen /ˈmaxn̩/', 'Buch /buːx/', 'Nacht /naxt/'] },
      listening: { title: 'Easy German — street interviews', source: 'Easy German', url: 'https://www.youtube.com/@EasyGerman/playlists' },
      speaking: ['Heute ist es kalt.', 'Es regnet viel im Juli.', 'Im Winter schneit es in Deutschland.', 'Die Sonne scheint.', 'Wie ist das Wetter bei dir?'],
      quiz: { q: 'Complete: ___ regnet.', options: ['Er', 'Es', 'Das'], answer: 1 },
      culture: 'Weather is the safest small talk in Germany. Complaining about it together is a small social ritual.'
    },
    {
      level: 'A1', topic: 'Perfekt — talking about the past',
      words: [w('gestern', 'yesterday', 'ˈɡɛstɐn'), w('heute', 'today', 'ˈhɔɪtə'), w('gemacht', 'done', 'ɡəˈmaxt'),
        w('gegangen', 'gone', 'ɡəˈɡaŋən'), w('gelernt', 'learned', 'ɡəˈlɛʁnt'), w('gesehen', 'seen', 'ɡəˈzeːən'),
        w('gehabt', 'had', 'ɡəˈhapt'), w('gewesen', 'been', 'ɡəˈveːzn̩'),
        w('Woche', 'week', 'ˈvɔxə', 'die'), w('Wochenende', 'weekend', 'ˈvɔxn̩ˌʔɛndə', 'das')],
      grammar: { title: 'haben / sein + past participle', body: 'Most verbs use haben. Verbs of movement and change of state use sein.',
        examples: ['Ich habe Deutsch gelernt.', 'Ich habe einen Film gesehen.', 'Ich bin nach Ahmedabad gefahren.', 'Ich bin müde gewesen.'] },
      pronunciation: { focus: 'ge- prefix', tip: 'Unstressed "ge-" is quick and dull, almost "guh": gemacht, gelernt.', words: ['gemacht /ɡəˈmaxt/', 'gelernt /ɡəˈlɛʁnt/', 'gesehen /ɡəˈzeːən/'] },
      listening: { title: 'Nicos Weg A2 — Perfekt', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/nicos-weg-a2/c-40760437' },
      speaking: ['Gestern habe ich Deutsch gelernt.', 'Ich habe einen Test gemacht.', 'Am Wochenende bin ich zu Hause gewesen.', 'Ich habe viel gelesen.', 'Wir sind ins Kino gegangen.'],
      quiz: { q: 'Complete: Ich ___ nach Berlin gefahren.', options: ['habe', 'bin', 'ist'], answer: 1 },
      culture: 'In spoken German the Perfekt does the work of the English simple past. Präteritum is mostly written.'
    },
    {
      level: 'A2', topic: 'Opinions and reasons',
      words: [w('meinen', 'to think', 'ˈmaɪnən'), w('glauben', 'to believe', 'ˈɡlaʊbn̩'), w('weil', 'because', 'vaɪl'),
        w('deshalb', 'therefore', 'ˈdɛshalp'), w('obwohl', 'although', 'ɔpˈvoːl'), w('Meinung', 'opinion', 'ˈmaɪnʊŋ', 'die'),
        w('wichtig', 'important', 'ˈvɪçtɪç'), w('Grund', 'reason', 'ɡʁʊnt', 'der'),
        w('Vorteil', 'advantage', 'ˈfoːɐ̯taɪl', 'der'), w('Nachteil', 'disadvantage', 'ˈnaːxtaɪl', 'der')],
      grammar: { title: 'weil sends the verb to the end', body: 'Subordinating conjunctions (weil, dass, obwohl, wenn) push the verb to final position.',
        examples: ['Ich lerne Deutsch, weil ich in Deutschland studieren möchte.', 'Ich glaube, dass Deutsch schwer ist.', 'Obwohl es schwer ist, lerne ich jeden Tag.'] },
      pronunciation: { focus: 'ich-Laut', tip: 'Soft "ch" after i and e: wichtig ends like a whispered "sh" with the tongue high.', words: ['wichtig /ˈvɪçtɪç/', 'ich /ɪç/', 'nicht /nɪçt/'] },
      listening: { title: 'Nicos Weg A2 — Meinungen', source: 'Deutsche Welle', url: 'https://learngerman.dw.com/en/nicos-weg-a2/c-40760437' },
      speaking: ['Meiner Meinung nach ist Deutsch wichtig.', 'Ich lerne Deutsch, weil ich in Deutschland studieren will.', 'Ein Vorteil ist die kostenlose Bildung.', 'Ein Nachteil ist die Sprache.', 'Ich glaube, dass ich B1 schaffen kann.'],
      quiz: { q: 'Correct: Ich lerne Deutsch, weil ich Deutschland ___.', options: ['mag', 'mag ich', 'ich mag'], answer: 0 },
      culture: 'German discussion style is direct. Disagreement with your argument is not disagreement with you.'
    },
    {
      level: 'A2', topic: 'Formal writing and emails',
      words: [w('Sehr geehrte', 'Dear (formal)', 'zeːɐ̯ ɡəˈʔeːɐ̯tə'), w('Anlage', 'attachment', 'ˈanlaːɡə', 'die'),
        w('bitten', 'to request', 'ˈbɪtn̩'), w('mitteilen', 'to inform', 'ˈmɪttaɪlən'), w('Rückmeldung', 'reply', 'ˈʁʏkmɛldʊŋ', 'die'),
        w('freundlich', 'kind', 'ˈfʁɔɪntlɪç'), w('Grüße', 'regards', 'ˈɡʁyːsə'), w('beifügen', 'to enclose', 'ˈbaɪfyːɡn̩'),
        w('Bescheinigung', 'confirmation', 'bəˈʃaɪnɪɡʊŋ', 'die'), w('Termin', 'appointment', 'tɛʁˈmiːn', 'der')],
      grammar: { title: 'Formal register', body: 'Use Sie, subjunctive politeness and full sentences. No contractions.',
        examples: ['Sehr geehrte Damen und Herren,', 'Ich möchte mich für den Masterstudiengang bewerben.', 'Könnten Sie mir bitte mitteilen, …', 'Mit freundlichen Grüßen, Pratham Sukhadia'] },
      pronunciation: { focus: 'stress in long compounds', tip: 'Compounds stress the first element: BEscheinigung, RÜCKmeldung.', words: ['Bescheinigung', 'Rückmeldung', 'Bewerbungsfrist'] },
      listening: { title: 'Goethe-Institut B1 sample materials', source: 'Goethe-Institut', url: 'https://www.goethe.de/en/spr/kup/prf/prf/gzb1.html' },
      speaking: ['Sehr geehrte Damen und Herren, ich habe eine Frage zur Bewerbung.', 'Ich füge meine Unterlagen bei.', 'Könnten Sie mir bitte einen Termin geben?', 'Ich bitte um eine kurze Rückmeldung.', 'Mit freundlichen Grüßen.'],
      quiz: { q: 'Formal closing?', options: ['Tschüss', 'Mit freundlichen Grüßen', 'Bis dann'], answer: 1 },
      culture: 'German administrative email is short, formal and factual. Warmth is signalled by correctness, not friendliness.'
    }
  ];

  /* ---------------- German sound guide ---------------- */
  const SOUNDS = [
    ['ä', '/ɛː/', 'like "e" in bed, held longer — Käse'],
    ['ö', '/øː/', 'say "eh", then round the lips — schön'],
    ['ü', '/yː/', 'say "ee", then round the lips — Tür'],
    ['ei', '/aɪ/', 'like English "eye" — mein'],
    ['ie', '/iː/', 'like English "ee" — wie'],
    ['eu / äu', '/ɔɪ/', 'like "oy" in boy — Freund'],
    ['ch (soft)', '/ç/', 'after e, i, ä, ö, ü — ich, nicht'],
    ['ch (hard)', '/x/', 'after a, o, u — Buch, machen'],
    ['sch', '/ʃ/', 'English "sh" — schön'],
    ['sp / st', '/ʃp/, /ʃt/', 'at word start becomes shp / sht — Student'],
    ['w', '/v/', 'English "v" — Wasser'],
    ['v', '/f/', 'usually English "f" — viel'],
    ['z', '/ts/', 'always "ts" — zwei'],
    ['ß', '/s/', 'sharp s, never "z" — Straße'],
    ['r (final)', '/ɐ/', 'softens to "ah" — Mutter'],
    ['-ig', '/ɪç/', 'ends like soft ch — wichtig']
  ];

  /* ---------------- English → German cross-links ---------------- */
  const CROSSLINK = {
    people: 'die Bevölkerung', population: 'die Bevölkerung', government: 'die Regierung',
    environment: 'die Umwelt', education: 'die Bildung', research: 'die Forschung',
    university: 'die Universität', student: 'der Student', economy: 'die Wirtschaft',
    development: 'die Entwicklung', society: 'die Gesellschaft', technology: 'die Technologie',
    health: 'die Gesundheit', work: 'die Arbeit', money: 'das Geld', city: 'die Stadt',
    country: 'das Land', language: 'die Sprache', knowledge: 'das Wissen', science: 'die Wissenschaft',
    problem: 'das Problem', solution: 'die Lösung', reason: 'der Grund', advantage: 'der Vorteil',
    disadvantage: 'der Nachteil', opinion: 'die Meinung', experience: 'die Erfahrung',
    industry: 'die Industrie', transport: 'der Verkehr', climate: 'das Klima',
    energy: 'die Energie', water: 'das Wasser', food: 'das Essen', family: 'die Familie',
    child: 'das Kind', school: 'die Schule', teacher: 'der Lehrer', company: 'die Firma',
    job: 'der Beruf', future: 'die Zukunft', history: 'die Geschichte', culture: 'die Kultur',
    law: 'das Gesetz', freedom: 'die Freiheit', growth: 'das Wachstum', change: 'die Veränderung',
    increase: 'die Zunahme', decrease: 'der Rückgang', result: 'das Ergebnis', effect: 'die Wirkung',
    cause: 'die Ursache', example: 'das Beispiel', decision: 'die Entscheidung', quality: 'die Qualität',
    quantity: 'die Menge', building: 'das Gebäude', traffic: 'der Verkehr', pollution: 'die Verschmutzung'
  };

  /* ---------------- academic alternatives fallback ---------------- */
  const ACADEMIC = {
    people: ['the population', 'individuals', 'members of society', 'residents', 'citizens', 'the public'],
    big: ['substantial', 'considerable', 'significant', 'extensive'],
    small: ['minor', 'marginal', 'limited', 'modest'],
    good: ['beneficial', 'favourable', 'advantageous', 'positive'],
    bad: ['detrimental', 'adverse', 'harmful', 'unfavourable'],
    important: ['crucial', 'vital', 'significant', 'pivotal'],
    increase: ['rise', 'grow', 'surge', 'climb', 'escalate'],
    decrease: ['decline', 'fall', 'drop', 'diminish', 'dwindle'],
    show: ['demonstrate', 'illustrate', 'indicate', 'reveal'],
    think: ['argue', 'contend', 'maintain', 'assert'],
    problem: ['issue', 'challenge', 'obstacle', 'drawback'],
    money: ['funding', 'capital', 'financial resources', 'expenditure'],
    children: ['young people', 'minors', 'youngsters', 'the younger generation'],
    a_lot: ['a considerable amount', 'a substantial proportion', 'a significant share']
  };

  /* ---------------- achievements ---------------- */
  const ACHIEVEMENTS = [
    { id: 'firstFlt', title: 'First FLT', desc: 'Completed your first full length test.' },
    { id: 'readingBreak', title: 'Reading breakthrough', desc: 'Reached 6.5 in Reading.' },
    { id: 'reading7', title: 'Band 7 Reading', desc: 'Reached 7.0 in Reading.' },
    { id: 'writingBreak', title: 'Writing breakthrough', desc: 'Reached 7.0 in Writing.' },
    { id: 'listening8', title: 'Listening 8.0', desc: 'Reached 8.0 in Listening.' },
    { id: 'overall7', title: 'Overall 7.0', desc: 'Logged an overall band of 7.0 or higher.' },
    { id: 'streak7', title: '7-day consistency', desc: 'Studied seven consecutive days.' },
    { id: 'streak30', title: '30-day discipline', desc: 'Held a 30-day study streak.' },
    { id: 'a1done', title: 'A1 complete', desc: 'Completed all A1 lessons in the lesson bank.' },
    { id: 'vocab500', title: 'Vocabulary 500', desc: 'Logged 500 vocabulary items.' },
    { id: 'german300', title: 'German 300', desc: 'Logged 300 German words.' },
    { id: 'mistakes50', title: 'Honest logger', desc: 'Recorded 50 mistakes with analysis.' },
    { id: 'hours100', title: '100 study hours', desc: 'Logged 100 hours of study.' },
    { id: 'uni5', title: 'Shortlist built', desc: 'Researched five universities.' },
    { id: 'docsHalf', title: 'Paperwork moving', desc: 'Half the document checklist completed.' }
  ];

  return {
    PROFILE, CLASSES, SCHEDULE, MODES, PHASES, SCHEMAS, MASTERY,
    READING_TYPES, LISTENING_ERRORS, WRITING_ERRORS,
    DOCS_SEED, RES_SEED, CEFR, TIPS, LESSONS, SOUNDS, CROSSLINK, ACADEMIC, ACHIEVEMENTS
  };
})();
